# The R2R Manifest

We will do our best to build useful AI tools for developers _(before AGI)_.
