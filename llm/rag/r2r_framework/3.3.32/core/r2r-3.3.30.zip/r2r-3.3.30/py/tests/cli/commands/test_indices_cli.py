"""
Tests for the indices commands in the CLI.
    x list
    x retrieve
    x delete
"""
