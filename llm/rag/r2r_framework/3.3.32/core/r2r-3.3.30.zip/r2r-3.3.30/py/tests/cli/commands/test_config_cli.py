"""
Tests for the conversations commands in the CLI.
    x reset
    x key
    x host
    x view
"""
